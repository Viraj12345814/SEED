package com.busbooking.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.busbooking.entity.Booking;

public interface BookingRepository extends JpaRepository<Booking, Integer> {

    List<Booking> findByUser_UserId(int userId);

	 List<Booking> findByBus_BusId(int busId);

}
