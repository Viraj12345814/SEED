package com.busbooking.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.busbooking.entity.Seats;

public interface SeatRepository extends JpaRepository<Seats, Long> {

    List<Seats> findByBus_BusId(Long busId);

}
